from deck_of_cards.classes import deck

bicycle = Deck()

# bicycle.show_cards()

def black_jack(dealer):
    dealer=[]
    player=[]
    player_score= dealer[0]+ dealer[1]
    dealer_score=0
    print('welcome to Black Jack')

def dealer(deck):
    sel